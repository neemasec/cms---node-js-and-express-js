const mongoose = require("mongoose");

const userSchema = mongoose.Schema({
    email : String,
    username : String,
    password : String,
    joinDate : {
        type:Date,
        default : Date.now
    },
})

User = mongoose.model("User",userSchema);

module.exports = User;