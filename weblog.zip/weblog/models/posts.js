const mongoose = require("mongoose");

const postSchema = mongoose.Schema({
    email : String,
    username : String,
    discript : String,
    blogname : String,
    createDate : {
        type:Date,
        default : Date.now
    },
})

Post = mongoose.model("Post",postSchema);

module.exports = Post;