const mongoose = require("mongoose");

const CommenttSchema = mongoose.Schema({
    email : String,
    username : String,
    discript : String,
    blogname : String,
    createDate : {
        type:Date,
        default : Date.now
    },
})

Commentt = mongoose.model("Commentt",CommenttSchema);

module.exports = Commentt;