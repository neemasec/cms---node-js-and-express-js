const express = require("express");
const router = express.Router();
const User = require("../models/users.js")
const Post = require("../models/posts.js")
const Commentt = require("../models/comments.js")

let users_list = "";

router.get("/showposts",(req,res)=>{
    Post.find({}, function (err, posts){
        i = 0 ;
        txt1 = ""
        while (i < posts.length){
            txt1 += `<a href=http://127.0.0.1:3000/posts/${posts[i].blogname}>${posts[i].blogname}</a><br>`;
            i++
        }
        res.send(`${txt1}`);
    })
});

router.get("/",(req,res)=>{
    console.log("Cookies : ", req.cookies)
    res.cookie("test","cookie for test" , {maxAge:1000}).render("home.pug", {message:"home page"});
});

router.get("/about",(req,res,next)=>{
    delete req.session.show_about
    res.clearCookie("test");
    next();
},(req,res)=>{
    res.send("about us");
});

router.get("/posts/:id",(req,res)=>{
    Post.find({blogname:req.params.id}, function (err, posts){
        if (!req.session.username || !req.session.email || !req.session.password){
            res.send("please log in first <a href=/users/login>log in</a>");
        }
        else{
            Commentt.find({blogname:req.params.id}, function (err, Commentt){
                i = 0 ;
                txt1 = ""
                while (i < Commentt.length){
                    txt1 += `${Commentt[i].discript} - `;
                    i++
                }
                res.render(`posts.pug`,{discript:(posts[0].discript) , blogname:posts[0].blogname , comments:txt1})
            })
        }
    })
})    

router.post("/posts/:id",(req,res)=>{  
    const userInfo = req.body;
    const newCommentt = new Commentt ({
        email : req.session.email,
        username : req.session.username,
        discript : userInfo.discript,
        blogname : req.params.id
    });
    newCommentt.save(function(err,Post){
        if(err){
            res.send("Comment not sended !")
        }else{
            res.send("Commentt send !")
        }
    })
    }
);

module.exports = router;