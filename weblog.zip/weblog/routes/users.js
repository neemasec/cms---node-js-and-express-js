const express = require("express");
const router = express.Router();
const User = require("../models/users.js")
const Post = require("../models/posts.js")

router.get("/sendposts",(req,res)=>{
    if (!req.session.username || !req.session.email || !req.session.password){
        res.render("sendpost.pug");
    }
    else{
        res.render("sendpost.pug", {type:"error" , user:req.session.username, email:req.session.email});
    }
})

router.post("/sendposts",(req,res)=>{  
    const userInfo = req.body;
    targetblogname = `${userInfo.blogname}`;
    Post.find({blogname:targetblogname}, function (err, posts){
        if(String(posts)==""){
            const newPost = new Post ({
                email : req.session.email,
                username : req.session.username,
                discript : userInfo.discript,
                blogname : userInfo.blogname
            });
            newPost.save(function(err,Post){
                if(err){
                    res.send("post not sended !")
                }else{
                    res.send("post send !")
                }
            })
        }
        else{
            res.send("this name for blog is already used")
        }
    });
    }
)

router.get("/register",(req,res)=>{
    if(req.session.show_about){
        req.session.show_about++;
    }else{
        req.session.show_about = 1
    }
    res.render("registerForm.pug", {message:`${req.session.show_about}`});
})

router.post("/register",(req,res)=>{
    const userInfo = req.body;
    if(!userInfo.username || !userInfo.email || !userInfo.password){
        res.send("please fill all inputs")
    }else{
        targetemail = `${userInfo.email}`;
        User.find({email:targetemail}, function (err, users){
            if(String(users)==""){
                const newUser = new User ({
                    username : userInfo.username ,
                    email : userInfo.email ,
                    password : userInfo.password
                });
                newUser.save(function(err,User){
                    if(err){
                        res.render("registerdone.pug", {message:"Data base error" , type:"error"})
                    }else{
                        req.session.username = userInfo.username ;
                        req.session.email = userInfo.email ;
                        req.session.password = userInfo.password ;
                        res.render("registerdone.pug", {message:"register done" , type:"succes" , user:newUser});
                    }
                })
            }
            else{
                res.send(`this email is registered`);
            }
        });
    }
})

router.get("/profile",(req,res)=>{
    if (!req.session.username || !req.session.email || !req.session.password){
        res.send("you are not logged in <br><a href='http://127.0.0.1:3000/users/login'>login</a>   <a href='127.0.0.1:3000/users/register'>register</a>")
    }
    else{
        res.render("profile.pug", {user:req.session.username , password:req.session.password , email:req.session.email});
    }
})

function updateuser(targetmail,targetusername) {
    var MongoClient = require('mongodb').MongoClient;
    var url = "mongodb://127.0.0.1:27017/";

    MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("test");
    var myquery = { email: targetmail };
    var newvalues = { $set: {username: targetusername } };
    dbo.collection("users").updateOne(myquery, newvalues, function(err, res) {
        if (err) throw err;
        console.log("1 document updated");
        db.close();
    });
    }); 
}

router.post('/profile', function(req, res){
    const userInfo = req.body;
    updateuser(req.session.email , userInfo.username)
    req.session.username = userInfo.username
    res.send('username updated');
})

router.post("/login",(req,res)=>{
    const userInfo = req.body;
    User.find({email:userInfo.email,password:userInfo.password}, function (err, users){
        if(String(users[0])=="undefined"){
            res.send("incorrect email or password")
        }else{
            let lll = users[0] ;
            req.session.username = lll.username ;
            req.session.email = userInfo.email ;
            req.session.password = userInfo.password ;
            res.send("login succesed");
        }
     })
})

router.get("/login",(req,res)=>{
    if (!req.session.username || !req.session.email || !req.session.password){
        res.render("login.pug");
    }
    else{
        res.render("login.pug", {type:"error" , user:req.session.username, email:req.session.email});
    }
})

router.get("/logout",(req,res)=>{
    req.session.destroy();
    res.send("logout succes <br><a href='http://127.0.0.1:3000/users/login'>login</a>   <a href='127.0.0.1:3000/users/register'>register</a>")
})

router.get("/:id/:age([0-9]{2})",(req,res)=>{
    res.send(`user with id ${req.params.id} and age is ${req.params.age}`);
})

router.get('*',(req,res)=>{
    res.send(`not found `)
})
module.exports = router;