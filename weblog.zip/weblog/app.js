const express = require("express");
const homerouter = require("./routes/index.js");
const usersrouter = require("./routes/users.js");
const bodyparser = require("body-parser");
const mongoose = require("mongoose");
const cookieParser = require("cookie-parser")
const session = require("express-session")

const app = express();
const port = 3000;

mongoose.connect("mongodb://localhost/")

const testlogger = function(req,res,next){
    console.log("logged");
    next();
}
app.use(bodyparser.urlencoded({extended:true}));
app.use(cookieParser());
app.use(session({
    secret : "this is secret session"
}));

app.set('view engine','pug');
app.set("views","./views")

app.use(express.static("public"));
app.use(express.static("images"));


app.use("/static",express.static("public"));
app.use("/images",express.static("images"));


app.use(testlogger);

app.use("/",homerouter)
app.use("/users",usersrouter)

app.listen(port,()=>{
    console.log("app is rining");
})